// src/pages/RecipePage.js
import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import RecipeList from '../components/RecipeList';
import { useNavigate } from 'react-router-dom';
import HomePage from './HomePage';


const RecipePage = () => {
  const location = useLocation();
  const { ingredients, time, mood } = location.state;
  const [recipes, setRecipes] = useState([]);

  useEffect(() => {
    const ingredientList = ingredients.split(',').map((ing) => ing.trim()).filter(Boolean);
    
    const fetchRecipes = async () => {
      let allResults = [];
      for (const ingredient of ingredientList) {
        const response = await fetch(`https://www.themealdb.com/api/json/v1/1/filter.php?i=${ingredient}`);
        const data = await response.json();
        if (data.meals) allResults.push(...data.meals);
      }
      
      const uniqueRecipes = Array.from(new Set(allResults.map((r) => r.idMeal))).map(
        (id) => allResults.find((recipe) => recipe.idMeal === id)
      );

      setRecipes(uniqueRecipes);
    };

    fetchRecipes();
  }, [ingredients]);
  const navigate = useNavigate();
  return (
    <div>
      <h2>Recipes Matching Your Ingredients</h2>
      <RecipeList recipes={recipes} />
      <button 
        onClick={() => navigate('/')} // Navigates to the home route
        style={{
          marginTop: '20px',
          padding: '10px 20px',
          backgroundColor: '#4CAF50', // Green button
          color: '#fff',
          border: 'none',
          borderRadius: '5px',
          cursor: 'pointer',
          fontSize: '1rem'
        }}
      >
        Back to Search
      </button>
    </div>
  );
};

export default RecipePage;
