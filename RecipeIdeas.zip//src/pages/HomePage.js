// src/pages/HomePage.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const HomePage = () => {
  const [ingredients, setIngredients] = useState('');
  const [time, setTime] = useState('');
  const [mood, setMood] = useState('');
  const navigate = useNavigate();

  const handleSearch = () => {
    navigate('/recipes', { state: { ingredients, time, mood } });
  };

  return (
    <div className="home-page">
      <h1>What would you like to eat? </h1>
      <div className="input-group">
        <label>Mood:</label>
        <select value={mood} onChange={(e) => setMood(e.target.value)}>
          <option value="">Select your mood</option>
          <option value="comfort">Comfort Food</option>
          <option value="healthy">Healthy</option>
          <option value="quick">Quick and Easy</option>
          <option value="fancy">Fancy</option>
        </select>
      </div>
      <div className="input-group">
        <label>Cooking Time :</label>
        <select value={time} onChange={(e) => setTime(e.target.value)}>
          <option value="">Select your time</option>
          <option value="">15 minutes</option>
          <option value="">30 minutes</option>
          <option value="">45 minutes</option>
          <option value="">60 minutes </option>
        </select>
        
      </div>
      
      <div className="input-group">
        <label>Ingredients:</label>
        <input className='custom-input'
          type="text"
          value={ingredients}
          onChange={(e) => setIngredients(e.target.value)}
          placeholder="Enter ingredients "
        />
      </div>
      <button onClick={handleSearch}>Search Recipes</button>
    </div>
  );
};

export default HomePage;
